package com.cg.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.training.entity.Player;

/**
 * Servlet implementation class Demo5
 */
@WebServlet("/Demo5")
public class Demo5 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	PrintWriter out=response.getWriter();
	Set<Player>	player=new HashSet<Player>();
	Player p1=new Player(10,"sachin",450,193467,150,true);
	Player p2=new Player(7,"dhoni",399,159546,154,true);
	Player p3=new Player(48,"raina",289,95487,98,false);
	Player p4=new Player(12,"yuvraj",278,125478,145,false);
	Player p5=new Player(45,"rohit",267,97845,57,false);
	Player p6=new Player(44,"sehwag",345,123456,87,false);
	Player p7=new Player(19,"dravid",412,564651,77,false);
	Player p8=new Player(34,"zaheer Khan",369,12345,987,false);
	Player p9=new Player(3,"harbhajan singh",312,124578,999,false);
	Player p10=new Player(99,"ashwin",344,322154,877,false);
	Player p11=new Player(8,"jadeja",294,456467,789,false);
	player.add(p1);
	player.add(p2);
	player.add(p3);
	player.add(p4);
	player.add(p5);
	player.add(p6);
	player.add(p7);
	player.add(p8);
	player.add(p9);
	player.add(p10);
	player.add(p11);
	out.println("<head>");
	out.println("<link href='style.css' rel='stylesheet'>");
	out.println("</head>");
	out.println("<table>");
	out.println("<tr><th>jersy number</th><th>PlayerName</th><th>NumberOfMathces</th><th>NumberOfRuns</th><th>numberOfWickets</th><th>Captain</th><th>BattingAverage</th><th>BowlingAverage</th></tr>");
	for (Player player2 : player) {
		out.println("<tr>");
		out.println("<td>"+player2.getPlayerId()+"</td>");
		out.println("<td>"+player2.getPlayerName()+"</td>");
		out.println("<td>"+player2.getNumberOfMatches()+"</td>");
		out.println("<td>"+player2.getTotalRunsScore()+"</td>");
		out.println("<td>"+player2.getNumberOfWickets()+"</td>");
		out.println("<td>"+player2.isCaptain()+"</td>");
		out.println("<td>"+player2.getBattingRating()+"</td>");
		out.println("<td>"+player2.getBowlingRating()+"</td>");
		out.println("</tr>");
	}
	out.println("</table>");
	}

}
