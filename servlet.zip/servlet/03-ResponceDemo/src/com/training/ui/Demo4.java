package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
* Servlet implementation class Demo4
*/
@WebServlet("/Demo4")
public class Demo4 extends HttpServlet {
                private static final long serialVersionUID = 1L;
       
   
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                doPost(request, response);
                }

                
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                PrintWriter out=response.getWriter();
                                String[] subjects={"English","Chemistry","social"};
                                double[] marks={70.0,75.0,81.0};
                                response.setContentType("text/html");
                                out.println("<table>");
                                for(int i=0;i<subjects.length;i++)
                                {
                                                out.println("<tr>");
                                                out.println("<td>"+subjects[i] +":"+ marks[i]+"<td>");
                                                out.println("</tr>");
                                                
                                                
                                }
                      
                                out.println("</table>");
                                for(int i=0;i<marks.length;i++){
                                	double mark=0;
                                	double markss=(marks[i]+mark)/3;
                                	out.println("TotalAvg:"+markss);
                                }
                                
                }

}
