package com.training.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.entity.Player;

/**
 * Servlet implementation class Demo5
 */
@WebServlet("/Demo5")
public class Demo5 extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 PrintWriter out=response.getWriter();
		 Set<Player> players=new HashSet<>();
		 Player player1=new Player(1, "sachin", 162, 10000, 35, false);
		 Player player2=new Player(2, "KL Rahul", 35, 1500, 0, false);
		 Player player3=new Player(3, "Kohli", 75, 9523, 11, false);
		 Player player4=new Player(4, "Rohit Sharma", 80, 8523, 7, false);
		 Player player5=new Player(5, "Dohni", 125, 9872, 45, true);
		 Player player6=new Player(6, "Venky", 10, 56, 3, false);
		 Player player7=new Player(7, "Raju", 11, 59, 4, false);
		 Player player8=new Player(8, "Rafi", 19, 56, 3, false);
		 Player player9=new Player(9, "Rahul", 20, 65, 5, false);
		 Player player10=new Player(10, "Ajay", 21, 90, 6, false);
		 Player player11=new Player(11, "Arjun", 22, 92, 7, false);
		 
		 
		 players.add(player1);
		 players.add(player2);
		 players.add(player3);
		 players.add(player4);
		 players.add(player5);
		 players.add(player6);
		 players.add(player7);
		 players.add(player8);
		 players.add(player9);
		 players.add(player10);
		 players.add(player11);
		 
		  response.setContentType("text/html");
		  out.println("<header>  CricketSquade </header>");
          out.println("<table>");
         // Iterator it=players.iterator();
          for (Player player : players) {
        	  out.println("<tr>");
        	  out.println("<td>" + player.getPlayerId()+"</td>"+"<dr>"+"<dr>");
        	  out.println("<dr>");
        	  out.println("<td>" + player.getPlayerName()+"</td>");
        	  out.println("<td>" + player.getTotalRunsScored()+"</td>");
        	  out.println("<td>" + player.getBattingRatting()+"</td>");
        	  out.println("<td>" + player.getNumberOfMatches()+"</td>");
        	  out.println("<td>" + player.getNumberOfWickets()+"</td>");
        	  
        	 
        	  out.println("</tr>");
          }
          out.println("</table>");
      
		 
		 
		 
	}

}
