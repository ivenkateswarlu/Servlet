package com.training.entity;

public class Player {
private int playerId;
private String playerName;
private  int numberOfMatches;
private int totalRunsScored;
private int numberOfWickets;
private boolean captian;


@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + (captian ? 1231 : 1237);
	result = prime * result + numberOfMatches;
	result = prime * result + numberOfWickets;
	result = prime * result + playerId;
	result = prime * result
			+ ((playerName == null) ? 0 : playerName.hashCode());
	result = prime * result + totalRunsScored;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Player other = (Player) obj;
	if (captian != other.captian)
		return false;
	if (numberOfMatches != other.numberOfMatches)
		return false;
	if (numberOfWickets != other.numberOfWickets)
		return false;
	if (playerId != other.playerId)
		return false;
	if (playerName == null) {
		if (other.playerName != null)
			return false;
	} else if (!playerName.equals(other.playerName))
		return false;
	if (totalRunsScored != other.totalRunsScored)
		return false;
	return true;
}
public Player() {
	super();
}
public Player(int playerId, String playerName, int numberOfMatches,
		int totalRunsScored, int numberOfWickets, boolean captian) {
	super();
	this.playerId = playerId;
	this.playerName = playerName;
	this.numberOfMatches = numberOfMatches;
	this.totalRunsScored = totalRunsScored;
	this.numberOfWickets = numberOfWickets;
	this.captian = captian;
}
@Override
public String toString() {
	return "Player [playerId=" + playerId + ", playerName=" + playerName
			+ ", numberOfMatches=" + numberOfMatches + ", totalRunsScored="
			+ totalRunsScored + ", numberOfWickets=" + numberOfWickets
			+ ", captian=" + captian + "]";
}
public int getPlayerId() {
	return playerId;
}
public void setPlayerId(int playerId) {
	this.playerId = playerId;
}
public String getPlayerName() {
	return playerName;
}
public void setPlayerName(String playerName) {
	this.playerName = playerName;
}
public int getNumberOfMatches() {
	return numberOfMatches;
}
public void setNumberOfMatches(int numberOfMatches) {
	this.numberOfMatches = numberOfMatches;
}
public int getTotalRunsScored() {
	return totalRunsScored;
}
public void setTotalRunsScored(int totalRunsScored) {
	this.totalRunsScored = totalRunsScored;
}
public int getNumberOfWickets() {
	return numberOfWickets;
}
public void setNumberOfWickets(int numberOfWickets) {
	this.numberOfWickets = numberOfWickets;
}
public boolean isCaptian() {
	return captian;
}
public void setCaptian(boolean captian) {
	this.captian = captian;
}

public String getBattingRatting(){
	double average=this.totalRunsScored/this.numberOfMatches;
	if(average>90){
		return "best";
	}
	else if(average>=50){
		return "Good";
	}
	else if(average>=25){
		return "Average";
	}
	else{
		return "poor";
	}
	/*public String getBowlingRatting(){
		double average=this.numberOfWickets/this.numberOfMatches;
		if(average>90){
			return "best";
		}
		else if(average>=50){
			return "Good";
		}
		else if(average>=25){
			return "Average";
		}
		else{
			return "poor";
		}*/
}
}
